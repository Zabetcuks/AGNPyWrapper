# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 14:40:31 2023

@author: Maksims Zabetcuks
"""

from setuptools import setup, find_packages


VERSION = '0.1.0'
DESCRIPTION = 'A python wrapper for simulating networks with the GNPy'
LONG_DESCRIPTION = 'A python wrapper for simulating networks with the GNPy'

# Setting up
setup(
    name="GNPy wrapper",
    version=VERSION,
    author="Maksims Zabetcuks",
    author_email="<zabetcuks@gmail.com>",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=['gnpy'],
    keywords=['python', 'gnpy', 'wrapper'],
    classifiers=[
        "Development Status :: Finished",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)