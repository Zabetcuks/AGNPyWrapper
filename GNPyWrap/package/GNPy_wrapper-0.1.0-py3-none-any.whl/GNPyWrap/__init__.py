# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 14:33:19 2023

@author: Maksims Zabetcuks
"""

from GNPyWrapper import (load_data, load_net, load_eqpt, create_path_request, customize_si, simulate, final_gsnr, customize_amp, customize_all_fiber,
                                  customize_roadm, customize_span, customize_one_fiber, print_path, sim_reach)
